<?php

/**
 * Fired during plugin deactivation
 *
 * @link              http://webnus.biz
 * @since             1.0.0
 * @package           time table
 */

/**
 * Fired during plugin deactivation.
 * This class defines all code necessary to run during the plugin's deactivation.
 */
class Wb_Tt_Deactivator {

	public static function deactivate() {
		// wb_post_type();
	 //    flush_rewrite_rules();
	}

}
